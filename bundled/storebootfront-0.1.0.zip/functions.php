<?php

add_action( 'wp_enqueue_scripts', 'enqueue_parent_styles' );

function enqueue_parent_styles() {
	wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
}


function storebootfront_assets() {
	wp_enqueue_style( 'storebootfront-stylesheet', get_stylesheet_directory_uri() . '/dist/css/main.css', array(), '1.0.0', 'all' );
	wp_enqueue_script( 'storebootfront-scripts', get_stylesheet_directory_uri() . '/dist/js/bundle.js', array(), '1.0.0', true );


}

add_action( 'wp_enqueue_scripts', 'storebootfront_assets' );